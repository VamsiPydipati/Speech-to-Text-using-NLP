import speech_recognition as sr

def live_speech_to_text():
    # Initialize recognizer
    recognizer = sr.Recognizer()
    
    # Use default microphone as source
    with sr.Microphone() as source:
        print("Listening...")  # Indicate that the program is listening
        recognizer.adjust_for_ambient_noise(source)  # Adjust for ambient noise
        audio_data = recognizer.listen(source)  # Listen to the microphone input
        
        try:
            print("Recognizing...")  # Indicate that the program is recognizing speech
            text = recognizer.recognize_google(audio_data)  # Use Google's speech recognition
            print("You said:", text)  # Print the recognized text
        except sr.UnknownValueError:
            print("Could not understand audio")  # Handle unrecognized audio
        except sr.RequestError as e:
            print("Could not request results; {0}".format(e))  # Handle request errors

# Call the function to start live speech-to-text transcription
live_speech_to_text()